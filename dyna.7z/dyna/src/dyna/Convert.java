package dyna;

public class Convert {
	public boolean getbbol(String a){
		System.out.println("call");
		return Boolean.parseBoolean(a);
	}
	public Convert() {
		super();
		System.out.println("converter");
	}

}
