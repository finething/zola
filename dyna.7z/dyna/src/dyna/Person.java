package dyna;

public class Person {
	private boolean what;
	private String name = "zelalem";
	Boolean bol;

	public Person() {
		super();
		System.out.println("person");
	}

	public boolean isWhat() {
		return what;
	}

	public void setWhat(boolean what) {
		this.what = what;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
