package dyna;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Applic {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext app = new ClassPathXmlApplicationContext("springConfig.xml");
		Person per=(Person)app.getBean("person");
		System.out.println(per.isWhat());
		

	}

}
